package parcelApp.parcel;

public class Parcel {
		
		//Declare attributes
		private double weight;
		private double price;
		
		
		private double getWeight() {
			return weight;
		}
		
		private void setWeight(double weight) {
			this.weight = weight;
		}
		
		private double getPrice() {
			return price;
		}
		
		private void setPrice(double price) {
			this.price = price;
		}

}
